export const jwtConstants = {
    secret: 'yasmeen',
  };