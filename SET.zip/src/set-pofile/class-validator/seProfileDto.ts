import { MaxLength, MinLength, IsNotEmpty, IsBoolean, ValidateNested, IsDefined, ArrayNotEmpty } from "class-validator";
import { Type } from "class-transformer";


class Feild {
    @MaxLength(255)
    @MinLength(1)
    @IsNotEmpty()
    public feildName: string;

    @MaxLength(255)
    @MinLength(1)
    @IsNotEmpty()
    public inputType: string;
}

class Section {
    @MaxLength(255)
    @MinLength(2)
    @IsDefined()
    @IsNotEmpty()
    public sectionName: string;

    @ValidateNested({ each: true })
    @Type(() => Feild)
    @ArrayNotEmpty()
    readonly feilds: Feild;
}

export class SetProfileDto {
    @MaxLength(255)
    @MinLength(2)
    readonly name: string;

    @MaxLength(255)
    @MinLength(1)
    readonly application: string;

    @IsBoolean()
    readonly isActive: boolean;

    @ValidateNested({ each: true })
    @Type(() => Section)
    @ArrayNotEmpty()
    readonly sections: Section;
}




