import * as mongoose from 'mongoose';


export const setSectionSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            minlength: 1,
            maxlength: 255
        },
        feilds: [
        ]
    },
    { timestamps: true },
);


export const SetProfileSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            minlength: 1,
            maxlength: 255
        },
        application: {
            type: String,
            required: true,
            minlength: 1,
            maxlength: 255
        },
        isActive: {
            type: Boolean,
            required: true,
            value: true,
        },
        sections: [{
            type: setSectionSchema,
        }
        ]
    },
    { timestamps: true },
);
