import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Req, Res } from '@nestjs/common';
import { Request, Response } from 'express';
import * as _ from 'lodash';

@Injectable()
export class SetProfileService {
    constructor(@InjectModel('Profile') private readonly setProfileModel: Model) { }

    async findAll() {
        let temp = await this.setProfileModel.find();
        return temp;
    }

    async addSetProfile(setProfile) {
        // Detect duplicate
        // var profile = await this.setProfileModel.findOne({
        //     name: setProfile.name,
        //     application: setProfile.application
        // });
        // if (!profile) {
        //     throw new HttpException('Already exist', HttpStatus.BAD_REQUEST);
        //   }
        const createdSetProfile = new this.setProfileModel(setProfile);
        let temp = await createdSetProfile.save();
        return temp;

    }

}
