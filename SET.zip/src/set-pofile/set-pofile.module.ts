import { Module } from '@nestjs/common';
import { SetProfileController } from './set-profile.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { SetProfileSchema } from './schema/set-profile';
import { SetProfileService } from './service/set-profile.service';

@Module({
  imports: [MongooseModule.forFeature([
    { name: 'Profile', schema: SetProfileSchema },
  ])],
  controllers: [SetProfileController],
  providers: [SetProfileService],
})
export class SetProfileModule {}
