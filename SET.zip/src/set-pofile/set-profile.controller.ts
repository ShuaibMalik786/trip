import { Response } from 'express';
import { AuthGuard } from '@nestjs/passport';
import { Controller, Get, Post, Res, Body, UseGuards, Param, Request, Put, HttpException, HttpStatus, Req } from '@nestjs/common';
import { SetProfileService } from './service/set-profile.service';
import { SetProfileDto } from './class-validator/seProfileDto';

@Controller('api/setProfile')
export class SetProfileController {
    constructor(private readonly setProfileService: SetProfileService) { }

    @Get()
    findAll() {
        let setProfile = this.setProfileService.findAll();
        return setProfile;
    }


    @Post()
    addSetProfileTemplate(@Body() setProfileDto: SetProfileDto) {
        // let setProfile = this.setProfileService.addSetProfile(setProfileDto);
        return setProfileDto;
    }
}
